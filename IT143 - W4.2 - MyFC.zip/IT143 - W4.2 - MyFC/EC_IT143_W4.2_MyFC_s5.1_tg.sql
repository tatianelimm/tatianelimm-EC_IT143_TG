
-- Step 5.1 � Create Table using SELECT INTO from View
SELECT * INTO t_MostSalary2019 FROM v_MostSalary2019;
Go

