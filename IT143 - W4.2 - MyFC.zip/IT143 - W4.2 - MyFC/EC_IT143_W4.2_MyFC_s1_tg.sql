-- Step 1 - Question: Which player had the highest salary on 2019?


