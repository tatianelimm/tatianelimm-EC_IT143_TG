
-- Step 5.2 � (Opcional) Add Primary Key 
ALTER TABLE t_MostSalary2019 ADD id INT IDENTITY(1,1) PRIMARY KEY;
Go
