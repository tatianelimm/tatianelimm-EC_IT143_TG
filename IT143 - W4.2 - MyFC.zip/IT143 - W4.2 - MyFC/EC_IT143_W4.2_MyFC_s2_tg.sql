
--Step 2 � Start the answer 
-- The players with the highest total salary on 2019-01-31 are:


