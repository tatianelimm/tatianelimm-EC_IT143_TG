
-- Step 4 � Create a View
CREATE OR ALTER VIEW v_MostSalary2019 AS
SELECT
    p.pl_name,
    t.t_code AS team,
    f.mtd_salary AS total_salary
FROM
    tblPlayerDim p
JOIN
    tblTeamDim t ON p.t_id = t.t_id
JOIN
    tblPlayerFact f ON f.pl_id = p.pl_id
WHERE
    f.as_of_date = '2019-01-31';
Go

