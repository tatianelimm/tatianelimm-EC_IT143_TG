
-- Step 8 � Execute the Procedure 
EXEC sp_MostSalary2019;




