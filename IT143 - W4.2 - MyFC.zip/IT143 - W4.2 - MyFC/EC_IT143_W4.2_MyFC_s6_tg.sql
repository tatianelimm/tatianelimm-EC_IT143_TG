
-- Step 6 � Populate the Table (TRUNCATE + INSERT)
TRUNCATE TABLE t_MostSalary2019;

INSERT INTO t_MostSalary2019 (pl_name, team, total_salary)
SELECT pl_name, team, total_salary
FROM v_MostSalary2019;
Go
