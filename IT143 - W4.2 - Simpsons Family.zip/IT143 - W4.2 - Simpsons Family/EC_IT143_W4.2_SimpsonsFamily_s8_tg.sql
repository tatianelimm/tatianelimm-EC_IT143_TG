
EXEC sp_ActiveSimpsons;
