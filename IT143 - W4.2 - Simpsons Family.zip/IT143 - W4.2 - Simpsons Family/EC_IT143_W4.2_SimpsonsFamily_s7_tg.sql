
CREATE OR ALTER PROCEDURE sp_ActiveSimpsons
AS
BEGIN
    TRUNCATE TABLE t_ActiveSimpsons;
    INSERT INTO t_ActiveSimpsons (Member_ID, Name, Job_Title, Status)
    SELECT Member_ID, Name, Job_Title, Status
    FROM v_ActiveSimpsons;
END
Go

