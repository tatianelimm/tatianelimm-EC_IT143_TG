

CREATE OR ALTER VIEW v_ActiveSimpsons AS
SELECT
    Member_ID,
    Name,
    Job_Title,
    Status
FROM
    SimpsonFamily
WHERE
    Status = 'Active';
Go


