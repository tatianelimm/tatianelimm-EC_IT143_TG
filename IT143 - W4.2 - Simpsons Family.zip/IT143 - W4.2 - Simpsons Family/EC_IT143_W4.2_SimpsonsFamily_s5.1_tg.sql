
SELECT * INTO t_ActiveSimpsons FROM v_ActiveSimpsons;
Go


