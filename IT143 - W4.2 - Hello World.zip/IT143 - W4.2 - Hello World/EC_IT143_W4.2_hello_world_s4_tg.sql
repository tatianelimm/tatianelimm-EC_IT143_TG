
-- Step 4 � Create a View
CREATE OR ALTER VIEW v_HelloWorld AS
SELECT SYSDATETIME() AS CurrentDateTime;
Go
