

-- Step 3 � Ad hoc query
SELECT SYSDATETIME() AS CurrentDateTime;
Go

