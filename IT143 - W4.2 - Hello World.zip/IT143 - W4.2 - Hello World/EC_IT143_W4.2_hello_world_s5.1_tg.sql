-- Step 5.1 � Create Table using SELECT INTO from View
SELECT * INTO t_HelloWorld FROM v_HelloWorld;
Go


