
-- Step 6 � Populate the Table (TRUNCATE + INSERT)
TRUNCATE TABLE t_HelloWorld;
Go
INSERT INTO t_HelloWorld (CurrentDateTime)
SELECT SYSDATETIME();
Go

