-- Step 7 � Create Stored Procedure
CREATE OR ALTER PROCEDURE sp_HelloWorld
AS
BEGIN
    TRUNCATE TABLE t_HelloWorld;
    INSERT INTO t_HelloWorld (CurrentDateTime)
    SELECT SYSDATETIME();
END
Go

